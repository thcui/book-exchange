import json
import boto3
from datetime import datetime
def insert_user_info(data_list, db=None, table='user-information'):
    if not db:
        db = boto3.resource('dynamodb')
    table = db.Table(table)
    # overwrite if the same index is provided
    for data in data_list:
        data['user_sign_up_time'] = datetime.now().astimezone().strftime("%H:%M:%S %Z, %m-%d-%Y")
        response = table.put_item(Item=data)
    print('@insert_data: response', response)
    return response
    
def insert_user_messages(data_list, db=None, table='book-exchange-message'):
    if not db:
        db = boto3.resource('dynamodb')
    table = db.Table(table)
    # overwrite if the same index is provided
    for data in data_list:
        data['user_sign_up_time'] = datetime.now().astimezone().strftime("%H:%M:%S %Z, %m-%d-%Y")
        response = table.put_item(Item=data)
    print('@insert_data: response', response)
    return response
    

def lambda_handler(event, context):
    insert_user_info([
        {
            "user_id":event['userName'],
            "current_credit":5,
            "donation_history":[],
            "favorite_list":[],
            "request_history":[]

        }])
    insert_user_messages([
        {
            "user_id":event['userName'],
            "messages":[]

        }])

    return event