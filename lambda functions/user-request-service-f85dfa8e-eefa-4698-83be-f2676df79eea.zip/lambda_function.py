import json
import boto3
from decimal import Decimal
#from datetime import datetime
import ast
import requests
import os
#from requests_aws4auth import AWS4Auth

    


# check whether user has enough credit to request the book
def check_credict(user_id, book_id):
    dynamodb = boto3.client('dynamodb', region_name='us-east-1')
    # table1 = dynamodb.Table('book-exchange-donation-information')
    # table2 = dynamodb.Table('user-information')
    book = dynamodb.get_item(TableName='book-exchange-donation-information', Key={'donation_id':{'S':book_id}})['Item']
    book_credit = int(book['credit']['N'])
    book_status = book['book_status']['S']
    print(book_status)
    user = dynamodb.get_item(TableName='user-information', Key={'user_id':{'S':user_id}})['Item']
    user_credit = int(user['current_credit']['N'])
    print("user", user_credit)
    print("book", book_credit)
    
    if user_credit < book_credit:
        print("failed")
        return False
    elif book_status == 'unavailable':
        return False
    else:
        print("success")
        return user_credit-book_credit


# successfully requested book will be unavailable in status
def update_book(book_id):
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table('book-exchange-donation-information')
    
    response = table.update_item(
    Key={
        'donation_id': book_id
    },
    UpdateExpression="set book_status= :r",
    ExpressionAttributeValues={
        ':r': 'unavailable',
    },
    ReturnValues="UPDATED_NEW"
    )
    return response
    
    
    

# add request history to user
def update_user(user_id, book_id):
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table('user-information')
    db = boto3.client('dynamodb', region_name='us-east-1')
    book = db.get_item(TableName='book-exchange-donation-information', Key={'donation_id':{'S':book_id}})['Item']
    book_credit = int(book['credit']['N'])
    result = table.update_item(
               Key={'user_id': user_id},
               UpdateExpression="SET request_history = list_append(request_history, :i), current_credit = current_credit - :c",
               ExpressionAttributeValues={':i': [book_id],':c': book_credit,},
               ReturnValues="UPDATED_NEW")
    return result

# give credit to seller
def update_seller(book_id):
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table('user-information')
    db = boto3.client('dynamodb', region_name='us-east-1')
    book = db.get_item(TableName='book-exchange-donation-information', Key={'donation_id':{'S':book_id}})['Item']
    seller = book['user_id']['S']
    book_credit = int(book['credit']['N'])
    print('seller', seller)
    result = table.update_item(
               Key={'user_id': seller},
               UpdateExpression="SET current_credit = current_credit + :c",
               ExpressionAttributeValues={':c': book_credit,},
               ReturnValues="UPDATED_NEW")
    return result



def lambda_handler(event, context):

    #request_info = event
    request_info = ast.literal_eval(event['body'])
    user_id = request_info['userName']
    book_id = request_info['bookId']
    user_credit=check_credict(user_id,book_id)
    if user_credit == False: 
        print("failed in main")
        return {
        'statusCode': 403,
        'headers': {
            'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Methods': 'POST,OPTIONS',
            'Access-Control-Allow-Origin': '*'
        },
        'body': 'Not enough credit or Book is already unavailable! Request Failed and Check AGAIN!!'
       # 'body': json.dumps(event['body'])
    }
    else:
        update_book(book_id)
        update_user(user_id, book_id)
        update_seller(book_id)
        print("success in main")
    
    
    # TODO implement
    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Methods': 'POST,OPTIONS',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps({'user_credit':user_credit})
    }