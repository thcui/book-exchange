import json
import boto3
from decimal import Decimal
from datetime import datetime
import ast
import requests
import os
from requests_aws4auth import AWS4Auth



def lookup_data(key, db=None, table='user-information'):
    if not db:
        db = boto3.resource('dynamodb')
    table = db.Table(table)
    try:
        response = table.get_item(Key=key)
    except ClientError as e:
        print('Error', e.response['Error']['Message'])
    else:
        print(response['Item'])
        return response['Item']

def insert_data(data_list, db=None, table='book-exchange-donation-information'):
    if not db:
        db = boto3.resource('dynamodb')
    table = db.Table(table)
    # overwrite if the same index is provided
    for data in data_list:
        data['insertedAtTimestamp'] = datetime.now().astimezone().strftime("%H:%M:%S %Z, %m-%d-%Y")
        response = table.put_item(Item=data)
    print('@insert_data: response', response)
    return response
    

def update_item(key, feature, db=None, table='user-information'):
    if not db:
        db = boto3.resource('dynamodb')
    table = db.Table(table)
    # change student location
    response = table.update_item(
        Key=key,
        UpdateExpression="set #feature=:f",
        ExpressionAttributeValues={
            ':f': feature
        },
        ExpressionAttributeNames={
            "#feature": "donation_history"
        },
        ReturnValues="UPDATED_NEW"
    )
    print(response)
    return response
    

def upload_to_openSearch(data):
    region = 'us-east-1'
    service = 'es'
    credentials = boto3.Session().get_credentials()
    awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)

    host = os.environ['OpenSearchDomainEndpoint'] # The OpenSearch domain endpoint with https://
    index = 'donation'
    url = "https://"+ host + '/' + index + '/doc'
    # Put the user query into the query DSL for more accurate search results.
    # Note that certain fields are boosted (^).

    # Make an explicit Content-Type header
    headers = {"Content-Type": "application/json"}

    # Make the signed HTTP request
    r = requests.post(url, auth=awsauth, headers=headers, data=json.dumps(data))

    print("from Opensearch:")
    print(r)
    return r
    
def get_api_info(book_name):
    search_name=book_name.replace(' ','+')
    openlibrary_related_info= requests.get("http://openlibrary.org/search.json?title="+search_name).json()['docs']
    if len(openlibrary_related_info)<=0:
        return{
            "genres":None,
            "description": None,
            "openlibrary_link": None
        }
    openlibrary_id= openlibrary_related_info[0]['key'] 
    book_info=requests.get("https://openlibrary.org"+openlibrary_id+".json").json()
    
    return{
            "genres":book_info['subjects'] if 'subjects' in book_info.keys() else None,
            "description":book_info['description'] if 'description' in book_info.keys() else None,
            "openlibrary_link": "https://openlibrary.org"+openlibrary_id
    }

    


def lambda_handler(event, context):

    donation_info=ast.literal_eval(event['body'])
    print(donation_info)
    book_api_info=get_api_info(donation_info['book_name'])
    donation_info['genres']=book_api_info['genres']
    donation_info['description']=book_api_info['description']
    donation_info['openlibrary_link']=book_api_info['openlibrary_link']
    donation_info['book_status']='available'
    insert_data([donation_info])
    user_donation_history=lookup_data({"user_id":donation_info['user_id']})['donation_history']
    user_donation_history.append(donation_info['book_name']+"(id:"+donation_info['donation_id']+")")
    update_item({"user_id":donation_info['user_id']},user_donation_history)


    
    
    donation_info_opensearch={
        'book_name':donation_info['book_name'],
        'donation_id':donation_info['donation_id'],
        'genres':donation_info['genres'],
        'condition':donation_info['condition']
    }
    upload_to_openSearch(donation_info_opensearch)
    
    
    # TODO implement
    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(event['body'])
    }
