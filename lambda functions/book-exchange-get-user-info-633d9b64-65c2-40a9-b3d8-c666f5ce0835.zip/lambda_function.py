import json
import boto3


def lookup_data(key, db=None, table='user-information'):
    if not db:
        db = boto3.resource('dynamodb')
    table = db.Table(table)
    try:
        response = table.get_item(Key=key)
    except ClientError as e:
        print('Error', e.response['Error']['Message'])
    else:
        print(response['Item'])
        return response['Item']



def lambda_handler(event, context):
    query=event["queryStringParameters"]
    user_info=lookup_data({"user_id":query['user_id']})
    user_info['current_credit']=int(user_info['current_credit'])
    # TODO implement
    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(user_info)
    }
