import json
import boto3
from datetime import datetime
import ast
def insert_data(data_list, db=None, table='user-information'):
    if not db:
        db = boto3.resource('dynamodb')
    table = db.Table(table)
    # overwrite if the same index is provided
    for data in data_list:
        data['user_sign_up_time'] = datetime.now().astimezone().strftime("%H:%M:%S %Z, %m-%d-%Y")
        response = table.put_item(Item=data)
    print('@insert_data: response', response)
    return response
    
def lookup_data(key, db=None, table='user-information'):
    if not db:
        db = boto3.resource('dynamodb')
    table = db.Table(table)
    try:
        response = table.get_item(Key=key)
    except ClientError as e:
        print('Error', e.response['Error']['Message'])
    else:
        print(response['Item'])
        return response['Item']

    

def update_item(key, feature, db=None, table='user-information'):
    if not db:
        db = boto3.resource('dynamodb')
    table = db.Table(table)
    # change student location
    response = table.update_item(
        Key=key,
        UpdateExpression="set #feature=:f",
        ExpressionAttributeValues={
            ':f': feature
        },
        ExpressionAttributeNames={
            "#feature": "favorite_list"
        },
        ReturnValues="UPDATED_NEW"
    )
    print(response)
    return response

    

def lambda_handler(event, context):
    body=ast.literal_eval(event['body'])
    print(body)
    fav_list=lookup_data({"user_id":body['user_id']})['favorite_list']
    if(fav_list is None):
        fav_list=[]
    print(fav_list)
    if('action' in body.keys() and body['action'] == 'remove'):
        fav_list.remove(body['book_name'])
    else: fav_list.append(body['book_name'])
    
    update_item({"user_id":body['user_id']},fav_list)

    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*'
        },
        'body': event['body']
    }