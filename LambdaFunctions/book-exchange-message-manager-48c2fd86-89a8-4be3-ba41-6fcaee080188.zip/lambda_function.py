import json
import boto3
import ast



def lookup_data(key, db=None, table='book-exchange-message'):
    if not db:
        db = boto3.resource('dynamodb')
    table = db.Table(table)
    try:
        response = table.get_item(Key=key)
    except ClientError as e:
        print('Error', e.response['Error']['Message'])
    else:
        print(response['Item'])
        return response['Item']
        
def update_item(key, feature, db=None, table='book-exchange-message'):
    if not db:
        db = boto3.resource('dynamodb')
    table = db.Table(table)
    # change student location
    response = table.update_item(
        Key=key,
        UpdateExpression="set #feature=:f",
        ExpressionAttributeValues={
            ':f': feature
        },
        ExpressionAttributeNames={
            "#feature": "messages"
        },
        ReturnValues="UPDATED_NEW"
    )
    print(response)
    return response
    

def get_email(user_name):
    client = boto3.client('cognito-idp')
    user_attrs=client.admin_get_user(
    UserPoolId='us-east-1_grhBaeiC4',
    Username=user_name)['UserAttributes']
    user_email=list(filter(lambda x: (x['Name'] == 'email'),user_attrs))
    if len(user_email)==0:
        return False
    return user_email[0]['Value']
def send_email(sender,recipient,content):
    SENDER="BookExchange <cthtyty@gmail.com>"
    user_email=get_email(recipient)
    if(user_email is False):
        return
    RECIPIENT = user_email
    #CONFIGURATION_SET = "ConfigSet"
    AWS_REGION = "us-east-1"
    SUBJECT = "NEW MESSAGE FROM BOOK-EXCHANGE"
    BODY_TEXT = "You received a new message from " + sender+ '. Here is the content: ' +content
    CHARSET = "UTF-8"
    client = boto3.client('ses',region_name=AWS_REGION)
    try:
        response = client.send_email(
            Destination={
        'ToAddresses': [
            RECIPIENT,
            ],
        },
        Message={
        'Body': {
            'Text': {
                'Charset': CHARSET,
                'Data': BODY_TEXT,
            },
        },
        'Subject': {
            'Charset': CHARSET,
            'Data': SUBJECT,
        },
    },
        Source=SENDER
        #ConfigurationSetName=CONFIGURATION_SET,
    )
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        print("Email sent! Message ID:"),
        print(response['MessageId'])


    

def lambda_handler(event, context):
    if(event['httpMethod']=='GET'):
        query=event["queryStringParameters"]
        user_id=query['user_id']
        print(user_id)
        print(type(user_id))
        user_messages=lookup_data({"user_id":user_id})
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps(user_messages)
        }
    message_info=ast.literal_eval(event['body'])
    sender=message_info['sender']
    recipient=message_info['recipient']
    content=message_info['content']
    user_messages=lookup_data(key={"user_id":recipient})['messages']
    user_messages.append({"sender":sender,"content":content})
    update_item({"user_id":recipient},user_messages)
    try:
        send_email(sender,recipient,content)
    except Error as e:
        print(e)
    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps('Success')
    }
