import json
import boto3
import ast
import random
import re
import requests
from requests_aws4auth import AWS4Auth
from requests.auth import HTTPBasicAuth
from decimal import Decimal

from boto3.dynamodb.conditions import Key


class DecimalEncoder(json.JSONEncoder):
  def default(self, obj):
    if isinstance(obj, Decimal):
      return str(obj)
    return json.JSONEncoder.default(self, obj)


def lambda_handler(event, context):
    # print(event)
    query_info = event['queryStringParameters']['book_name']
    # book_name = re.split(r'[.,!#$ -_?%^]', query_info)
    # for name in book_name:
    #     name.lower()
    book_name = query_info.lower()
    # print(book_name)
    os_response = opensearch_query(book_name)

    
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table('book-exchange-donation-information')
    
    
    id_list = []
    response = []
    if "hits" in os_response:
        for hit in os_response["hits"]["hits"]:
            d_id = hit["_source"]["donation_id"]
            info = table.query(KeyConditionExpression=Key('donation_id').eq(d_id))
            for item in info['Items']:
                if (item['book_status'] == "available"):
                    book_info = {}
                    book_info["credit"] = item["credit"]
                    book_info["book_name"] = item["book_name"]
                    book_info["condition"] = item["condition"]
                    if 'user' in item and len(item["user"]):
                        book_info["user"] = item["user"]
                    else:
                        book_info["user"] = item["user_id"]
                    book_info["description"] = item["description"]
                    book_info["donation_id"] = item["donation_id"]
                    book_info["genres"] = item["genres"]
                    
                   
                    # if len(book_cover_link):
                    #     book_info["cover_photos_links"] = book_cover_link
                    # else:
                    #     book_info["cover_photos_links"] = "https://book-exchange-book-photos-bucket.s3.amazonaws.com/no-image.jpg"
    
                    # if len(item["photos_links"]):
                    #     book_info["detail_photos_links"] = "https://book-exchange-book-photos-bucket.s3.amazonaws.com/" + item["photos_links"][0]
                    # else:
                    #     book_info["detail_photos_links"] = "https://book-exchange-book-photos-bucket.s3.amazonaws.com/no-image.jpg"
                    if len(item["photos_links"]):
                        book_info["cover_photos_links"] = 'https://book-exchange-book-photos-bucket.s3.amazonaws.com/' + item["photos_links"][0]
                    else:
                        book_cover_link = get_book_cover(book_name)
                        if len(book_cover_link):
                            book_info["cover_photos_links"] = book_cover_link
                        else:
                            book_info["cover_photos_links"] = "https://book-exchange-book-photos-bucket.s3.amazonaws.com/no-image.jpg"
                        # book_info["cover_photos_links"] = "https://book-exchange-book-photos-bucket.s3.amazonaws.com/no-image.jpg"
                    # print(book_info["detail_photos_links"])
                    response.append(book_info)
    
    print(response)
    
    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*',
        },
        'body': json.dumps(response, cls=DecimalEncoder)
    }
    

# function to get donation id
def opensearch_query(book_name):
    region = 'us-east-1' 
    service = 'opensearchservice'
    credentials = boto3.Session().get_credentials()
    awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, 'es', session_token=credentials.token)
    
    host = "https://search-book-exchange-donation-info-a6674i5bcjdvwgbnqd24njqyyi.us-east-1.es.amazonaws.com"
    index = 'donation'
    url = host + '/' + index + '/_search'
    
    headers = {"Content-Type": "application/json"}
    query = {
        "query": {
            "match": {
                "book_name": book_name
            }
        }
    }
    
    # Make the signed HTTP request
    r = requests.get(url, auth=awsauth, headers=headers, data=json.dumps(query))
    
    # return the body of response
    r = json.loads(r.text)
    return r

# function to get book cover through api
def get_book_cover(book_name):
    search_name=book_name.replace(' ','+')
    openlibrary_related_info= requests.get("http://openlibrary.org/search.json?title="+search_name).json()['docs']
    if len(openlibrary_related_info)<=0:
        return None
        
    openlibrary_id= openlibrary_related_info[0]['key'] 
    book_info=requests.get("https://openlibrary.org"+openlibrary_id+".json").json()
    book_cover="https://covers.openlibrary.org/b/id/"+str(book_info["covers"][0])+"-M.jpg"
    # openlibrary_books_cover = openlibrary_related_info[0]['seed']
    # length = len(openlibrary_books_cover)
    
    # book_cover = ""
    # if index >= length:
    #     openlibrary_id = openlibrary_books_cover[length - 1][7:]
    # else:
    #     openlibrary_id = openlibrary_books_cover[index][7:]
        
    # book_cover = "https://covers.openlibrary.org/b/olid/"+openlibrary_id+"-M.jpg"
    
    return book_cover
